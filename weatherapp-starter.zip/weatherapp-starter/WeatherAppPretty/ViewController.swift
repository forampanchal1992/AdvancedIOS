//
//  ViewController.swift
//  WeatherAppPretty
//
//  Created by robin on 2018-07-15.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Alamofire            // 1. Import AlamoFire and SwiftyJson
import SwiftyJSON
import ChameleonFramework         // optional - used to make colors pretty
import CoreLocation               // TODO: Add location later


class ViewController: UIViewController, CLLocationManagerDelegate {

    // --------------------------------------------
    // MARK: User interface outlets
    // --------------------------------------------
    @IBOutlet weak var labelLocation: UILabel!
    @IBOutlet weak var labelDate: UILabel!
    @IBOutlet weak var labelTemp: UILabel!
    @IBOutlet weak var imageWeatherIcon: UIImageView!
    @IBOutlet weak var labelHumidity: UILabel!
    @IBOutlet weak var labelVisibility: UILabel!
    @IBOutlet weak var labelRain: UILabel!
    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    
    // Make a CoreLocation variable
    var manager : CLLocationManager!
    
    // --------------------------------------------
    // TODO: url variables
    // --------------------------------------------
    let URL = "https://api.darksky.net/forecast/ff41689fc242d7783a79fab7ae586b2b/"
    let LOCATION = "28.7041,77.1025"
    let PARAMS = "?exclude=minutely,hourly,daily,alerts,flags&units=ca"

    
    let url = "https://api.darksky.net/forecast/ff41689fc242d7783a79fab7ae586b2b/28.7041,77.1025?exclude=minutely,hourly,daily,alerts,flags&units=ca"
    
    // --------------------------------------------
    // TODO: Add location variables
    // --------------------------------------------
    
    // put your location variables here
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // UI NONSENSE - Make a gradient background using Chameleon
        let colors:[UIColor] = [
            UIColor(hexString:"#F27121")!,
            UIColor(hexString:"#E94057")!,
            UIColor(hexString:"#8A2387")!
        ]
        view.backgroundColor = UIColor(gradientStyle:UIGradientStyle.topToBottom, withFrame:view.frame, andColors:colors)

        
        self.manager = CLLocationManager()
        self.manager.delegate = self
        
        // 2. Tell ios how accurate you want the location to be
        self.manager.desiredAccuracy = kCLLocationAccuracyBest
        
        // 3. Ask the user for permission to get their location
        self.manager.requestAlwaysAuthorization()
        
        // 4. Get the user's location
        self.manager.startUpdatingLocation()
        
        
        // TODO: Get the current location
        //  do this later
        
        
        // TODO: Get the weather
        getWeather(url:url)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func refreshWeather(_ sender: Any) {
        // TODO: Refresh the weather data.
        print("refresh weather button pushed")
        getWeather(url: url)
        
    }

    @IBAction func btnLocationPressed(_ sender: UIButton) {
        
        print("Location button pressed")
        
        //1.get the current lat/lon
        let lat = manager.location!.coordinate.latitude
        let long = manager.location!.coordinate.longitude
        
        //2.build your URL  with the lat/long
        let loc = "\(lat),\(long)"
        
        let u = "\(URL)\(loc)\(PARAMS)"
        
        print(u)
        
        //go to updated weather
        getWeather(url: u)
        
    }
    
    func getWeather(url:String) {
        // Build the URL:
        
        
        
        print(url)
        
        
        
        Alamofire.request(url, method: .get, parameters: nil).responseJSON {
            
            (response) in
            
            if response.result.isSuccess {
                if let dataFromServer = response.data {
                    
        
                    do {
                        let json = try JSON(data: dataFromServer)
                        
                        // TODO: Parse the json response
                        print(json)
                        
                         // TODO: Display the results
                        let current = json["currently"].dictionary
                        let date = current!["time"]!.doubleValue
                        //let date = current!["time"]!.doubleValue
                        let temp = current!["temperature"]!.doubleValue
                        let status = current!["summary"]!.stringValue
                        var humidity = current!["humidity"]!.doubleValue
                        var rainchance = current!["precipProbability"]!.doubleValue
                        let windspeed = current!["windSpeed"]!.doubleValue
                        
                        //do math conersion you need
                        humidity = humidity * 100
                        rainchance = rainchance * 100
                        
                        //do a date conversion
                        var dateFromTimeStamp = Date(timeIntervalSince1970: date)
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.timeZone = TimeZone(abbreviation: "EST")
                        
                        //formate the date --- Wednesday JULY 24,2018
                        dateFormatter.dateFormat = "EEEE, MMM d, yyyy"
                        let day = dateFormatter.string(from: dateFromTimeStamp)
                        
                        //update the navigation
                        self.title = day
                        
                        //formate the time as 8:52pm
                        dateFormatter.dateFormat = "h:mm a"
                        let timeString = dateFormatter.string(from:dateFromTimeStamp)

                        
                        //update the label
                        
                        
                        /*
                       // let time = json["currently"]["time"].stringValue
                        let sumry = json["currently"]["summary"].stringValue
                        let t = json["currently"]["temperature"].stringValue
                        let h = json["currently"]["humidity"].stringValue
                        let rain = json["currently"]["precipType"].stringValue
                        let s = json["currently"]["windSpeed"].stringValue
                        */
                        print("\(timeString)")
                        print("\(temp)")
                        print("\(status)")
                        print("\(String(format:"%.0f", humidity))%")
                        print("\(String(format:"%.0f", rainchance))%")
                        print("\(windspeed)km/h")
                        
                        
                        self.labelDate.text = "Last Updated: \(timeString)"
                        self.labelTemp.text = "\(temp)"
                        self.labelHumidity.text = "\(String(format:"%.0f", humidity))%"
                        self.labelVisibility.text = "\(windspeed)km/h"
                        self.labelRain.text = "\(String(format:"%.0f", rainchance))%"
                        self.labelStatus.text = "\(status)"
                       
                        
                    }
                    catch {
                        print("error")
                    }
                    
                }
                else {
                    print("Error when getting JSON from the response")
                }
            }
            else {
                // 6. You got an error while trying to connect to the API
                print("Error while fetching data from URL")
            }
            
        }
        

    }
    
    
    // --------------------------------------------
    // TODO: Add location
    // --------------------------------------------
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // this function gets called every time the person's location changes
        print("location updated!")

        
        
    }
    

}

